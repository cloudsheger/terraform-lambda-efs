#!/usr/bin/env bash

# Change to the script directory
cd "$(dirname "$0")" || exit
pip install -r requirements.txt -t package/